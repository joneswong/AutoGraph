from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


class Space(object):

    def __init__(self, default_value):
        self.default_value = default_value
